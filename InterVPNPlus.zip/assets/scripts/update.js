function updateApp() {
    alert("La app se está actualizando...");
}
