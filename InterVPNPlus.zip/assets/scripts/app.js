document.getElementById("toggleVPN").addEventListener("click", function() {
    const vpnStatus = document.getElementById("toggleVPN").textContent;
    if (vpnStatus === "Conectar VPN") {
        document.getElementById("toggleVPN").textContent = "Desconectar VPN";
    } else {
        document.getElementById("toggleVPN").textContent = "Conectar VPN";
    }
});

document.getElementById("updateBtn").addEventListener("click", function() {
    updateApp();
});

function updateApp() {
    alert("Actualización en progreso...");
}
